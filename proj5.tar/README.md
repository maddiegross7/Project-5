So I was the only one to work on this project so I did this by myself
I did take a lot of direction from the videos that crumpton posted they were very
helpful

I am pretty sure that my time complexity would be categorized as O(n^2) since there are
various cases of for loops within for loops which can take longer, I used nodes and edges 
to accomplish this and created a connected graph but that meant iterating through a few 
lists here and there